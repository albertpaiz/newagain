"""
settings.py — Konfigurasi Variational Volume Farming Bot
=========================================================

TIPS FARMING VOLUME:
  - Semakin besar saldo → semakin besar volume per trade
  - Leverage tinggi = volume lebih besar dari saldo yang sama
  - Variational biasanya kasih rewards berdasarkan total volume
  - Timing sengaja dibikin nggak seragam (hold & cooldown random dalam
    rentang lebar) supaya pola aktivitas nggak terlalu "robotic"

ESTIMASI VOLUME HARIAN (dengan saldo $100, timing default sekarang):
  - Trade size ~$72 per posisi
  - 1 cycle (max hold ~6.5 menit + cooldown ~6.5 menit) rata-rata ~13 menit
    → tapi biasanya lebih cepat karena TP/SL sering kena duluan → ~110 cycle/hari
  - Volume/hari ≈ $72 × 2 × ~110 cycle ≈ $15,800/hari (perkiraan kasar)
"""

# ─── REFERRAL ─────────────────────────────────────────────────────────────────
REFERRAL_CODE = ""

# ─── CLOUDFLARE / CAPTCHA ─────────────────────────────────────────────────────
# Kalau cookie manual di user_data/cf_cookies.txt basi/mismatch, bot otomatis
# fallback ke login SIWE resmi + solve Turnstile lewat 2captcha.
# Daftar & isi saldo di https://2captcha.com lalu taruh API key kamu di sini
# (atau lebih aman: di environment variable CAPTCHA_API_KEY).
import os
CAPTCHA = {
    "api_key": os.environ.get("CAPTCHA_API_KEY", ""),  # isi API key 2captcha kamu
    "enabled": True,
}

# ─── BALANCE AUTO-SIZING ──────────────────────────────────────────────────────
BALANCE = {
    # Pakai 80% saldo per trade (agresif untuk farming)
    # Contoh saldo $100 → trade size $72-$80
    "usage_pct": 0.80,

    # Sisakan 10% sebagai cadangan (untuk fee & buffer)
    "reserve_pct": 0.10,

    # Minimum size — sesuaikan dengan saldo kamu
    # Saldo $1   → set 0.5
    # Saldo $10  → set 5
    # Saldo $100 → set 10
    "min_size_usd": 0.5,

    # Maksimum size per trade (None = tidak ada batas)
    # Set ini untuk kontrol risiko
    "max_size_usd": None,

    # Refresh saldo setiap N cycle
    "refresh_every_n_cycles": 10,
}

# ─── TRADING ──────────────────────────────────────────────────────────────────
TRADING = {
    # Market dengan likuiditas terbaik = slippage minimal
    # Tambah lebih banyak untuk variasi volume
    "markets": ["BTC", "ETH", "SOL", "SUI"],

    "order_type": "MARKET",

    # Slippage 3% — lebih ketat dari default supaya tidak rugi banyak
    "slippage": 0.03,

    # Auto-close: posisi ditutup lebih cepat kalau kena target ini,
    # nggak nunggu hold_time_range abis dulu. hold_time_range di DELAYS
    # tetap dipakai sebagai batas waktu MAX (fallback kalau TP/SL nggak kena).
    "take_profit_pct": 2.0,
    "stop_loss_pct": 1.0,

    # Seberapa sering cek floating PnL selama posisi terbuka (detik)
    "pnl_check_interval": 5,
}

# ─── TELEGRAM ─────────────────────────────────────────────────────────────────
# Isi BOT_TOKEN dari @BotFather dan CHAT_ID kamu (bisa cek via @userinfobot).
# Bisa juga diisi lewat environment variable TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID
# supaya token nggak ketempel di source code.
import os as _os
TELEGRAM = {
    "enabled": True,
    "bot_token": _os.environ.get("TELEGRAM_BOT_TOKEN", ""),
    "chat_id": _os.environ.get("TELEGRAM_CHAT_ID", ""),

    # Auto-notif kalau posisi floating PnL minus lebih dari sekian persen
    "pnl_alert_pct": 5.0,

    # Kirim ringkasan session tiap N jam (0 = matikan)
    "report_every_hours": 6,
}

# ─── TIMING ───────────────────────────────────────────────────────────────────
# Dibikin lebih pelan & variatif supaya pola trading nggak keliatan "robotic"
# (hindari cycle super cepat & konsisten yang gampang ke-flag sebagai bot)
DELAYS = {
    # Max hold 3-10 menit — jaring pengaman kalau TP/SL nggak kena
    "hold_time_range": [180, 600],

    # Jeda antar cycle 3-10 menit — cukup "manusiawi" tapi tetep dapet
    # ±150-300 cycle/hari
    "between_cycles": [180, 600],

    # Jeda saat error
    "on_error": 60,
}
