"""
Variational Bot - Constants
"""
from pathlib import Path

USER_DATA_DIR = Path("user_data")
PRIVATE_KEYS_FILE = USER_DATA_DIR / "private_keys.txt"
DATABASE_FILE = Path("database") / "variational_bot.db"

PATHS = {
    'user_data': str(USER_DATA_DIR),
    'private_keys': str(PRIVATE_KEYS_FILE),
    'database': str(DATABASE_FILE),
}

BASE_URL = "https://omni.variational.io/api"
PRICE_API_URL = "https://omni-client-api.prod.ap-northeast-1.variational.io"
PRICE_CACHE_TTL = 5.0

CHAIN_ID = 42161
USDC_CONTRACT = "0xaf88d065e77c8cc2239327c5edb3a432268e5831"
SETTLEMENT_POOL_CONTRACT = "0xce94caf3d9ef916d2e4a83913fd899b1cd152fa2"

DEFAULT_FUNDING_INTERVAL = 3600
DEFAULT_SETTLEMENT_ASSET = "USDC"
DEFAULT_INSTRUMENT_TYPE = "perpetual_future"

RETRY_SETTINGS = {
    'max_retries': 3,
    'base_delay': 1.0,
}

HTTP_TIMEOUT_SETTINGS = {
    'connect_timeout': 15,
    'total_timeout': 30,
    'read_timeout': 45,
    'positions_timeout': 25,
}

JWT_CONFIG = {
    'lifetime_days': 7,
    'refresh_before_expiry_hours': 24,
}

ONBOARDING_CONFIG = {
    'auto_onboard_enabled': True,
    'delay_between_accounts': 10.0,
}

USDC_PERMIT_DOMAIN = {
    'name': 'USD Coin',
    'version': '2',
    'chainId': hex(CHAIN_ID),
    'verifyingContract': USDC_CONTRACT,
}

CLOUDFLARE_CONFIG = {
    'cookie_refresh_interval': 1800,
    'cf_clearance_lifetime': 1800,
    'cfbm_lifetime': 1800,
    'turnstile_sitekey': '0x4AAAAAAA2uzUXt_KvBDwd3',
    'page_url': 'https://omni.variational.io',
}
