"""
Logger module
"""
import logging
import sys
from pathlib import Path


class ColorLogger:
    """Logger dengan warna dan success level"""

    COLORS = {
        'DEBUG':   '\033[36m',   # Cyan
        'INFO':    '\033[37m',   # White
        'SUCCESS': '\033[32m',   # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR':   '\033[31m',   # Red
        'RESET':   '\033[0m',
    }

    def __init__(self, name: str = "variational_bot", level: str = "INFO"):
        self.name = name
        self.level = getattr(logging, level.upper(), logging.INFO)

        # File handler
        Path("logs").mkdir(exist_ok=True)
        logging.basicConfig(
            level=self.level,
            format="%(asctime)s [%(levelname)s] %(message)s",
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler("logs/bot.log", encoding="utf-8"),
            ]
        )
        self._logger = logging.getLogger(name)

    def _log(self, level: str, msg: str):
        color = self.COLORS.get(level, '')
        reset = self.COLORS['RESET']
        print(f"{color}{msg}{reset}", flush=True)
        getattr(self._logger, level.lower() if level != 'SUCCESS' else 'info')(msg)

    def debug(self, msg: str):   self._log('DEBUG', msg)
    def info(self, msg: str):    self._log('INFO', msg)
    def success(self, msg: str): self._log('SUCCESS', f"✅ {msg}")
    def warning(self, msg: str): self._log('WARNING', f"⚠️  {msg}")
    def error(self, msg: str):   self._log('ERROR', f"❌ {msg}")


def setup_logger(name: str = "variational_bot", level: str = "INFO") -> ColorLogger:
    return ColorLogger(name=name, level=level)
